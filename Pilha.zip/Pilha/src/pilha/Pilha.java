/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilha;

/**
 *
 * @author Vitória
 */
public class Pilha {
    //cria um objeto do tipo array de 5 posição
    Object[] pilha = new Object[5];
    //cria uma variável do tipo inteiro chamada topo que será inicializada na posição -1
	int topo = -1;
	
	//Criação do método inserir que vai ser denominado push e vai ter como parametro o objeto valor
	void push(Object valor) {
            //condição if determiará que se a pilha não estiver cheia (isfull) topo será encrementado,
            //e a pilha receberá esse novo valor e o alocará no topo(seguindo a regra básica de funcionamento
            //de uma pilha
		if (!isFull()) {
			topo++;
			pilha[topo] = valor;
		}else {
                    //caso a pilha esteja cheia, o usuário será alertado com essa mensagem
			System.out.println("Pilha cheia.");
		}
	}
	
	//Criação do método remover que vai ser denominado pop e não receberá nenhum parametro
        //pois a função dele é remover qualquer elemento que esteja no topo
        
	Object pop() {
            // Condição determinará que se a pilha estivar vazia o usuário receberá a mensagem que está no SYSO
		if(isEmpty()) {
			System.out.println("Pilha vazia");
			return null;
		}else {
			Object temp = pilha[topo];
			pilha[topo] = null;
			topo--;
			return temp;
		}
	}
	// Metodo topo sem parametros 
	Object top() {
		if(isEmpty()) {
			System.out.println("Pilha vazia");
			return null;
		}else {
			return pilha[topo];
		}
	}
	 //metodo tamanho
	int size() {
		return topo +1;
	}

	//maneira elegante
        // metodo auxiliar que dirá se a pilha está vazia
	boolean isEmpty() {
		return topo == -1;
	}//maneira elegante
	//metodo auxiliar que a pilha está cheia	
boolean isFull() {
		return topo == pilha.length - 1;
	}
	//metodo do tipo string para imprimir a pilha
	String imprimir() {
		String retorno = "";
		for (int i = topo; i >= 0; i--) {
			retorno += pilha[i] + " ";
		}
		return retorno;
	}
	
//	boolean isEmpty() {
//		if (topo == -1) {
//			return true;
//		}else {
//			return false;
//		}
//	}
	
	//consultar o topo


    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
