/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilha;
import javax.swing.JOptionPane;

/**
 *
 * @author Vitória
 */
public class usaPilha {
    public static void main(String[] args) {
		Pilha p1 = new Pilha();
		boolean continuar = true;
		
		while(continuar) {
			String op = JOptionPane.showInputDialog("1: Inserir \n "
                                                              + "2: Remover \n "
                                                              + "3: Exibir \n "
                                                              + "4: Quantidade \n "
                                                              + "5: Topo \n "
                                                              + "6: Sair");
			
			switch (op) {
			case "1":
				String valor = JOptionPane.showInputDialog("Digite o valor a ser inserido:");
				p1.push(valor);
				break;

			case "2":
				Object removido = p1.pop();
				JOptionPane.showMessageDialog(null, "Valor removido: " + removido);
				break;

			case "3":
				JOptionPane.showMessageDialog(null, p1.imprimir());
				break;

			case "4":
				JOptionPane.showMessageDialog(null, "Quantidade de elementos: " + p1.size());
				break;

			case "5":
				JOptionPane.showMessageDialog(null, "Elemento do topo: " + p1.top());
				break;

			case "6":
				continuar = false;
				break;

			default:
				JOptionPane.showMessageDialog(null, "Digite um valor válido.");
				break;
			}
		}
		
	}
}

    

