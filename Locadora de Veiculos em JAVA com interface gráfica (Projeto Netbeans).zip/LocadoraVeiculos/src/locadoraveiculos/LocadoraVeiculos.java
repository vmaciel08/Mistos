/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locadoraveiculos;

/**
 *
 * @author bcosta
 */
import java.util.Scanner;
public class LocadoraVeiculos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //Veiculos v = new Veiculos("Ford", "New Fiesta", "ABC-1234", "Preto", 2014, 200.00);
        //Veiculos b = new Veiculos("Ford", "Van", "ABC-2234", "Preto", 2013, 500.00);

       // System.out.print(v.toString());
        //System.out.print(b.toString());
        
        
    }
    
}
