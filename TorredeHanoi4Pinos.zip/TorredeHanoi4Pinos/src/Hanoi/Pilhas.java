package Hanoi;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.Iterator;
import java.util.Stack;

public class Pilhas {
       
    
        // ALTURA DOS PINOS
	private static final int ALT_PINO = 1000;

	// ALTURA DO DISCO
	private static final float ALT_DISCO = (float) 4.5;
 
        
	private Stack<Rectangle2D> disco = new Stack<Rectangle2D>();
	
	// COORDENADA DO TOPO DO DISCO
	private double base;
	
	// COORDENADA X DO PINO
	private int x;
	
	// COORDENADA Y DO PINO
	private double y;
	
	// ESPAÇO ENTRE DISCOS
	private static final int ESPACO_DISCO = 1;
	
	// The needle
	private Line2D pino;
	
	public Pilhas (int x, int y) {
		this.x = x;
		this.y = y;
		base = y;
		
		pino = new Line2D.Double(x, y, x, y - ALT_PINO);
	}
            // ADICIONAR LARGURA NO DISCO
        
	public void Empilhar (int largura) {
	
                Rectangle2D novodisco = new Rectangle2D.Double(0, 0, largura, ALT_DISCO);
		Empilhar (novodisco);
        
	}
	
	/*
	 ADICIONAR UM DISCO NO TOPO DO PINO
	 */
        
	public void Empilhar (Rectangle2D novodisco) {
		double esq_disco = x - novodisco.getWidth()/2;
		double topo_disco = y - ALT_DISCO - ESPACO_DISCO;
		y = topo_disco;
		novodisco.setFrame(esq_disco, topo_disco, novodisco.getWidth(), novodisco.getHeight());
		disco.push(novodisco);
	}
	
	/*
            REMOVER DISCO DO TOPO
	 */
	public Rectangle2D Desempilhar () {
		y = y + disco.peek().getHeight() + ESPACO_DISCO;
		return disco.pop();
	}
	
	/**
         *  REMOVER TODOS OS DISCOS
	 */
	public void Apagar() {
		disco.clear();
		y = base;
	}
	
	/**
	 * DESENHAR PINOS E DISCOS
	 */
	public void paint(Graphics2D desenho) {
		desenho.draw(pino);

		Iterator<Rectangle2D> iteracao = disco.iterator();
		while (iteracao.hasNext()) {
			desenho.fill(iteracao.next());
		}
	}
}
