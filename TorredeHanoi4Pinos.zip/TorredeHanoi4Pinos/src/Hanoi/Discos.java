package Hanoi;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;
import javax.swing.JOptionPane;

public class Discos extends JComponent implements Runnable
{

        private int movimentos = 0;
        // A velocidade real de animação 
	private static final int VELOCIDADE = 12000;
	
	// Largura do disco mais pequeno
	private static final int MENOR_DISCO = 10;	
	
	// Diferença de largura entre discos
	private static final int DIFERENCALARGURA_DISCO = 20;		

	// Pausa entre movimentos
	private int delay;				
	
	// Número de discos 
	private int num_disco;		
	
	// Número de pinos
	private static final int num_pinos = 3;
	
	// Criar pinos
	private Pilhas[] pinos = new Pilhas[num_pinos];
	// Posição dos pinos
	 
	public Discos(int numdisco, int tamanhojanela, int linhabase)
	{
		int primeirapilha = tamanhojanela/10;
		
		// Crie as pilhas para segurar os discos e desenhe as linhas para representar os pinos
		
		for (int i = 0; i < num_pinos; i++) {
			int x = primeirapilha + 2 * i * primeirapilha;
			pinos[i] = new Pilhas(x, linhabase);
		}
		
		setDiscos(numdisco);
	}

	
	//Colorir tela 
	public void paintComponent (Graphics g) {
		
                super.paintComponent(g);
		// tela 
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0, 0, getWidth(), getHeight());
		
		// discos e pinos
		g.setColor(Color.GREEN);
		for (int i = 0; i < num_pinos; i++) {
		 pinos[i].paint((Graphics2D) g); 
		}
	}
	
        
	public void run()
	{
            movimentos = 0;
		try {
			Thread.sleep(2*delay);
			Hanoi(num_disco, pinos[0], pinos[1], pinos[2]);
                        
		} catch (InterruptedException e) {
			
		}
		
	}
	
	private void Hanoi(int num_discos, Pilhas Origem, Pilhas Trabalho, Pilhas Destino) throws InterruptedException {
        if (num_discos == 1) {
            mover(Origem, Destino);
            movimentos++;
            Hanoi.contador.setText(Integer.toString(movimentos));//Inserir movimentos no contador
        } else {
            Hanoi(num_discos - 2, Origem, Destino, Trabalho);
            mover(Origem, Trabalho);
            movimentos++;
            mover(Origem, Destino);
            movimentos++;
            Hanoi(num_discos - 2, Trabalho, Origem, Destino);
        }
        //
        Hanoi.contador.setText(Integer.toString(movimentos));//Inserir movimentos no contador
            
	}
	
	// Colorir e Mover discos
	private void mover (Pilhas Primeiro, Pilhas Ultimo) throws InterruptedException
	{
		
		// Mover o disco
		Rectangle2D diskToMove = Primeiro.Desempilhar();
		Ultimo.Empilhar(diskToMove);
		repaint();
		Thread.sleep(delay);
                
             
	}
	
	
	public void SetVelocidade(int velocidade)
	{
		delay = VELOCIDADE/velocidade;
	}
	
	// Apagar disco das pilhas
	public void clear()
	{
		for (int i = 0; i < num_pinos; i++) {
			pinos[i].Apagar();
		}
		repaint();
	}

	
	public void setDiscos(int numDiscos) {
		assert numDiscos > 0;
		this.num_disco = numDiscos;
		
		
		for (int diskNum = num_disco; diskNum > 0; diskNum--)
		{
                    if (numDiscos > 0 && numDiscos<=10) {
                     int diskOffset = MENOR_DISCO+ (diskNum * DIFERENCALARGURA_DISCO) / 2;
			pinos[0].Empilhar (2*diskOffset);    
                    }else if (numDiscos > 10 && numDiscos<=20) {
                        int diskOffset = MENOR_DISCO - 1+ (diskNum * (DIFERENCALARGURA_DISCO - 10)) / 2;
			pinos[0].Empilhar (2*diskOffset); 
                    }else if (numDiscos > 20 && numDiscos<=30) {
                        int diskOffset = MENOR_DISCO - 2+ (diskNum * (DIFERENCALARGURA_DISCO - 11)) / 2;
			pinos[0].Empilhar (2*diskOffset); 
                    }else if (numDiscos > 30 && numDiscos<=40) {
                        int diskOffset = MENOR_DISCO - 3+ (diskNum * (DIFERENCALARGURA_DISCO - 12)) / 2;
			pinos[0].Empilhar (2*diskOffset); 
                    }else if (numDiscos > 40 && numDiscos<=50) {
                        int diskOffset = MENOR_DISCO - 4+ (diskNum * (DIFERENCALARGURA_DISCO - 13)) / 2;
			pinos[0].Empilhar (2*diskOffset); 
                    }else if (numDiscos > 50 && numDiscos<=60) {
                        int diskOffset = MENOR_DISCO - 5+ (diskNum * (DIFERENCALARGURA_DISCO - 14)) / 2;
			pinos[0].Empilhar (2*diskOffset); 
                    }else if (numDiscos > 60 && numDiscos<=70) {
                        int diskOffset = MENOR_DISCO - 6+ (diskNum * (DIFERENCALARGURA_DISCO - 15)) / 2;
			pinos[0].Empilhar (2*diskOffset); 
                    }else if (numDiscos > 70 && numDiscos<=80) {
                        int diskOffset = MENOR_DISCO - 7+ (diskNum * (DIFERENCALARGURA_DISCO - 16)) / 2;
			pinos[0].Empilhar (2*diskOffset); 
                    }else if (numDiscos > 80 && numDiscos<=90) {
                        int diskOffset = MENOR_DISCO - 8+ (diskNum * (DIFERENCALARGURA_DISCO - 17)) / 2;
			pinos[0].Empilhar (2*diskOffset); 
                    }else if (numDiscos > 90 && numDiscos<=100) {
                        int diskOffset = MENOR_DISCO - 9+ (diskNum * (DIFERENCALARGURA_DISCO - 18)) / 2;
			pinos[0].Empilhar (2*diskOffset); 
                    }

		}
		repaint();
	}
	
}