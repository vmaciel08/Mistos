package Hanoi;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Hanoi extends JPanel implements ActionListener, ChangeListener{
     
        // TAMANHO DA JANELA
	private static final int TamJanela = 1600;		
	
	// ALTURA DA LINHA BASE DOS DISCOS
	private static final int LinhaBase = 570;
	
	// BOTAO FIM
	private JButton FimButton;
        
        // BOTAO INICIAR
	private JButton IniciarButton;
        
	// NUMERO DE DISCOS INICIAIS
	private int NumDiscos = 10; 
        
	// DISPLAY DA INTERFACE
	private Discos NDiscos = new Discos(NumDiscos, TamJanela, LinhaBase);

	// SELECIONAR DISCOS
	private JTextField totaldisco = new JTextField("" + NumDiscos, 10);
        static JLabel contador = new JLabel();
        
	// ALTERAR VELOCIDADE
	private JSlider velocidade;

	private Thread hanoiThread;
        
        
	
        
        
        // CRIAÇÃO DOS ELEMENTOS DA INTERFACE
	public Hanoi() {
            
                setLayout (new BorderLayout());
		
		JPanel topPanel = new JPanel();
		Box topBox = new Box(BoxLayout.Y_AXIS);

		JPanel speedPanel = new JPanel();
		speedPanel.add(new JLabel("VELOCIDADE", JLabel.RIGHT));
		velocidade = new JSlider(JSlider.HORIZONTAL, 10, 100, 10);
		velocidade.addChangeListener(this);
		speedPanel.add(velocidade);
		topBox.add(speedPanel);
		
		JPanel diskPanel = new JPanel();
		diskPanel.add(new JLabel("QTD DISCO", JLabel.RIGHT));
		diskPanel.add(totaldisco);
		topBox.add(diskPanel);
		topPanel.add(topBox);
                
                JPanel diskPanel2 = new JPanel();
		diskPanel2.add(new JLabel("MOVIMENTOS", JLabel.RIGHT));
		diskPanel2.add(contador);
		topBox.add(diskPanel2);
		topPanel.add(topBox);
                
                
		JPanel bottomPanel = new JPanel();
		IniciarButton = new JButton("INICIAR");
		bottomPanel.add(IniciarButton);
		IniciarButton.addActionListener(this);
                    
                
		add(topPanel, BorderLayout.NORTH);
		add (NDiscos, BorderLayout.CENTER);
		add(bottomPanel, BorderLayout.SOUTH);
                
                
	}
       
	
	public void stateChanged(ChangeEvent evt) {
		if (NDiscos != null) {
			NDiscos.SetVelocidade(velocidade.getValue());
		}
	}

	public void actionPerformed(ActionEvent evt) {
		
		if (NDiscos != null) {
			NDiscos.clear();
		}
		
		if (hanoiThread != null) {
			hanoiThread.interrupt();
		}

		
		String stringValue = totaldisco.getText();
		try {
			NumDiscos = Integer.parseInt(stringValue);
		} catch (NumberFormatException e) {
		
		}

		NDiscos.setDiscos(NumDiscos);
		NDiscos.SetVelocidade(velocidade.getValue());
		
		hanoiThread = new Thread(NDiscos);
		hanoiThread.start();
	}

	public static void main(String[] args) {
            Discos d = new Discos(WIDTH, TamJanela, LinhaBase);
            JFrame f = new JFrame();
		f.setTitle("TORRE DE HANOI");
		f.setSize(new Dimension(1500, 740));

		Hanoi hanoi = new Hanoi();
		f.getContentPane().add(hanoi, BorderLayout.CENTER);

		f.setVisible(true);
               

	}


}