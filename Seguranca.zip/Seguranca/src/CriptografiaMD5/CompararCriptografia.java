/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CriptografiaMD5;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import sun.applet.Main;

/**
 *
 * @author Vitória
 */
public class CompararCriptografia {
    //gerar codigo hexadecimal
    private static String stringHexa(byte[] bytes){
        StringBuilder s = new StringBuilder();
        for(int i =0; i< bytes.length; i++){
            int parteAlta = ((bytes[i] >> 4) & 0xf) <<4;
            int parteBaixa = bytes[i] & 0xf;
            if(parteAlta ==0){
                s.append('0');
            }
            s.append(Integer.toHexString(parteAlta | parteBaixa));
            
        }
        return s.toString();
    }
    public static byte[] gerarHash(String frase, String algoritmo){
        try {
            MessageDigest md = MessageDigest.getInstance(algoritmo);
            md.update(frase.getBytes());
            return md.digest();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
        
    }
    public void main(String[] args){
        String frase = "Quero gerar códigos hash desta mensagem!";
        System.out.println(stringHexa(gerarHash(frase, "MD5")));
        System.out.println(stringHexa(gerarHash(frase, "SHA-512")));
        System.out.println(stringHexa(gerarHash(frase, "SHA-256")));
    } 
}
