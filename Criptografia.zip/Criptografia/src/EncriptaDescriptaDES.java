/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.swing.JOptionPane;
/**
 *
 * @author Vitória
 */
public class EncriptaDescriptaDES {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("DES");
            SecretKey chaveDES = keyGenerator.generateKey();
            // Providencia a funcionalidade da criptografia
            Cipher cifraDES;
            
            //Cria a cifra
            cifraDES = Cipher.getInstance("DES/ECB/PKCS5Padding");
            
            //Inicializa a cifra para o processo de encriptação
            cifraDES.init(Cipher.ENCRYPT_MODE,chaveDES);
            
            //Texto puro
            String n = JOptionPane.showInputDialog("Digite uma palavra:");
            byte[] textoPuro = n.getBytes();
            
            System.out.println( "Texto puro:"+ new String(textoPuro));
            
            //texto encriptado
            byte[] textoEcriptado = cifraDES.doFinal(textoPuro);
            System.out.println("Texto Encriptado: "+ textoEcriptado);
            
            //Inicializa a cifra também para o processo de decriptação
            cifraDES.init(Cipher.DECRYPT_MODE, chaveDES);
            
            //Decptografa o texto
            byte[] textoDecriptografado = cifraDES.doFinal(textoEcriptado);
             System.out.println("Texto Decriptografado: "+ new String(textoDecriptografado));
           
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e){
            e.printStackTrace();
        } catch (InvalidKeyException e){
            e.printStackTrace();
        } catch (IllegalBlockSizeException e){
            e.printStackTrace();
        } catch (BadPaddingException e){
            e.printStackTrace();
        }
            
        
    }

    
}
