/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BuscaEmProfundidade;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author Vitória
 */
public final  class Mapa {
    
    private Cidade origem;
    private Cidade destino;
    List<Cidade> listaCidade;
    
    public Mapa(){
        origem = new Cidade("Quixada");
        destino = new Cidade("Fortaleza");
        listaCidade = new ArrayList<>();
        listaCidade.add(origem);
        todasCidades();
    }

    public Cidade getOrigem() {
        return origem;
    }

    public void setOrigem(Cidade origem) {
        this.origem = origem;
    }

    public Cidade getDestino() {
        return destino;
    }

    public void setDestino(Cidade destino) {
        this.destino = destino;
    }
    public void cadastrarCidades(String nomeCidade){
        Cidade novaCidade;
        if(listaCidade.size()==1){
            novaCidade = getOrigem();
        }else{
            novaCidade = new Cidade(nomeCidade);
            
        }
        int opcao =0;
        while(true){
            String vizinho = JOptionPane.showInputDialog("Adicionar nome da Cidade vizinha de: "+novaCidade.getNome());
            Cidade novovizinho = new Cidade(vizinho);
            vizinho cidadevizinho = new vizinho(novovizinho);
            novaCidade.adicionarVizinho(cidadevizinho);
            opcao = JOptionPane.showConfirmDialog(null,"Deseja adicionar outro vizinho de "+novaCidade.getNome());
            
                if(opcao ==1){
                    listaCidade.add(novaCidade);
                    break;
                }
            
        }
    }
    public void todasCidades () {
        String[] todasCidades = {"Quixeramobim","Morada Nova","Ibicuitinga","Ibaretama","Fortaleza"};
        for(int i =0; i< todasCidades.length;i++){
            String cidade = todasCidades[i];
            cadastrarCidades(cidade);
        }
}
    }
    

