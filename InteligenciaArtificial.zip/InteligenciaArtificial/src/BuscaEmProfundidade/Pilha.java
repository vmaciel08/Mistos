/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BuscaEmProfundidade;
import java.util.LinkedList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Vitória
 */
public class Pilha {
    
    private List<Cidade> empilharCidade;
    
   public Pilha(){
        this.empilharCidade = new LinkedList<Cidade>();
        
    }
    public void empilhar(Cidade novo_cidade){
        empilharCidade.add(novo_cidade);
    }
   public Cidade getTopo(){
       if(empilharCidade.size()==0){
       return null;
   }else{
    return empilharCidade.get(this.empilharCidade.size()-1);
}
}
   public Cidade desempilhar(){
       return empilharCidade.remove
      (this.empilharCidade.size()-1);
   }
}
