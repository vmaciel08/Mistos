/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BuscaEmProfundidade;

/**
 *
 * @author Vitória
 */
public class BuscaEmProfundidade {
    
    private Pilha fronteira;
    private Cidade inicio;
    private Cidade objetivo;
    private boolean achou;
    
    public BuscaEmProfundidade( Cidade inicio, Cidade Objetivo){
        this.inicio = inicio;
        this.inicio.setVisitado(true);
        this.objetivo = objetivo;
        this.fronteira = new Pilha();
        this.fronteira.empilhar(inicio);
        this.achou = false;
        
    }
    
    public void buscarCidade(){
        Cidade topo = fronteira.getTopo();
        System.out.println("Topo: "+ topo.getNome());
        
        if(topo== objetivo){
            achou = true;
        }else {
            for(vizinho v : topo.getVizinhos()){
                if(!achou){
                System.out.println("Verificando se já foi "+v.getCidade().getNome());
                }
                if(!v.getCidade().isVisitado()){
                    v.getCidade().setVisitado(true);
                    fronteira.empilhar(v.getCidade());
                    buscarCidade();
                }
            }
        }
     
        System.out.println("Desempilhou: "+ fronteira.desempilhar().getNome());
    }
       
    public static void main(String[] args){
        System.out.println("Carregando mapa...");
        Mapa mapa = new Mapa();
        BuscaEmProfundidade busca = new BuscaEmProfundidade(mapa.getOrigem(),mapa.getDestino());
        busca.buscarCidade();
}   
}

 
