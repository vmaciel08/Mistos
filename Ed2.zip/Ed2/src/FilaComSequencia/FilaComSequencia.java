/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FilaComSequencia;


import AulaListaDuplamenteEncadeada.SequenciaDuplamenteEncadeada;
import aulaFila.FilaEncadeada;

/**
 *
 * @author Vitória
 */
public class FilaComSequencia {
    //FilaEncadeada fe = new FilaEncadeada();
    SequenciaDuplamenteEncadeada seq = new SequenciaDuplamenteEncadeada();
    
    public void enfileirar(Object valor){
        seq.insertLast(valor);
    }
    public Object desenfileirar(){
        return seq.removerDaPrimeiraPosicao();
    }
    public Object primeiroDaFila(){
        
             return seq.retornaPrimeiroNo();
    }
    public void imprimir(){
        seq.imprimir();
    }
}
