/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vitória
 */
public class No {
    private Object valor;
	private No ant;
	
        public No() {
		
	}
	
	public No(Object valor){
		this.valor = valor;
	}
	
	public No(Object valor, No ant){
		this.valor = valor;
		this.ant = ant;
	}
	
	public void setValor(Object valor) {
		this.valor = valor;
	}
	
	public Object getValor() {
		return valor;
	}
	

	public No getAnt() {
		return ant;
	}
        public void setAnt(No ant) {
		this.ant = ant;
	}

}
