/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vitória
 */
public class UsaPilhaEncadeada {
    public static void main(String[] args) {
		PilhaEncadeada p1 = new PilhaEncadeada();
		p1.push("A");
		p1.push("B");
		//System.out.println(p1.top());
		//p1.push("C");
		p1.pop();
		p1.push("D");
		p1.imprimir();
	}

    
}
