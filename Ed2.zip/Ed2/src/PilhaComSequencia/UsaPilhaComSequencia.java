/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PilhaComSequencia;

/**
 *
 * @author Vitória
 */
public class UsaPilhaComSequencia {
    public static void main(String[] args) {
        
        PilhaComSequencia pilha = new PilhaComSequencia();
        
        pilha.push("A");
        pilha.push("B");
        pilha.push("C");
        pilha.push("D");
        pilha.push("E");
        pilha.pop();
        pilha.push("Z");
        pilha.imprimir();
    }
}
