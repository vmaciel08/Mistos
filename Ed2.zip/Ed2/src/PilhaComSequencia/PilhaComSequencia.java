/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PilhaComSequencia;

import AulaListaDuplamenteEncadeada.SequenciaDuplamenteEncadeada;

/**
 *
 * @author Vitória
 */
public class PilhaComSequencia {
    SequenciaDuplamenteEncadeada seq = new SequenciaDuplamenteEncadeada();
    
    public void push(Object valor){
        seq.insertFirst(valor);
    }
    public Object pop(){
        return seq.removerDaPrimeiraPosicao();
    }
    public Object top(){
        return seq.retornaPrimeiroNo().getValor();
    }
    public int size(){
        return seq.size();
    }
    public void imprimir(){
        seq.imprimir();
    }
}
