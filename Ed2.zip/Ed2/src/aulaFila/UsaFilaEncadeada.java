/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaFila;

/**
 *
 * @author Vitória
 */
public class UsaFilaEncadeada {
    public static void main(String[] args){
    FilaEncadeada fila = new FilaEncadeada();
    
   // fila.enfileirar("A");
    fila.enfileirar("B");
    fila.enfileirar("C");
    fila.enfileirar("D");
    //fila.removerNo(fila.primeiroNo().getProx().getProx());
   //fila.enfileirarDobrado("A");
   //fila.enfileirarDobrado("B");
   //fila.enfileirarDobrado("C");
    //fila.desenfileirar();

    //System.out.println(fila.consultarPorPosicao( 2));
    fila.consultarOrdemInversa();
       // System.out.println(fila.consultarPorObject("A"));
           fila.imprimir();
}
}