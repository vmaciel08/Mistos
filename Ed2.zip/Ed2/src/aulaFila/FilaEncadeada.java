/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaFila;


/**
 *
 * @author Vitória
 */
public class FilaEncadeada {
    
    //cria uma variável do tipo inteiro chamada topo que será inicializada na posição -1
    No topo = null;
    private int qtd;
    
    
    Object[] pilha = new Object[qtd];
    private No ini;
    private No fim;
    public void enfileirar(Object valor) {
		No novoNo = new No(valor);
		if (isEmpty()) {
			ini = novoNo;
		}else {
			fim.setProx(novoNo);
		}
		fim = novoNo;
		qtd++;
	}
    
    
    public No removerNo(No no){
        if(isEmpty()){
            System.out.println("Fila vazia!");
            return null;
        }else{
           No n = ini;
           while(n.getProx() !=null){
                //para garantir que dois objetos desses tipos, com o mesmo conteúdo
                //possam ser considerados iguais foi usado o método equals
               if(n.getProx().getValor().equals(no.getValor())){
                   n.setProx(no.getProx());
                   n = n.getProx();
               }
               n = n.getProx();
           }
           return no;
        }
    }
    public No primeiroNo(){
        if(isEmpty()){
            System.out.println("Fila vazia!");
            return null;
            
        }
        return ini;
    }
    public void enfileirarDobrado(Object valor){
        No novoNo1 = new No(valor);
        No novoNo2 = new No(valor);
        if(isEmpty()){ //situação com fila sem elementos
            ini = novoNo1;
            fim = novoNo2;
            ini.setProx(fim);
            
        }
        else{
       novoNo1.setProx(ini);
       ini = novoNo1;
       fim.setProx(novoNo2);
       fim = novoNo2;
        
    }
   
    qtd ++;
    qtd++;
    } 
    
   /* public void enfileirarcomPilha(Object valor){
        No  novoNo = new No(valor);
        push(valor);
        if(isEmpty()){
            ini = novoNo;
            
        }
        else{
        fim.setProx(novoNo);
 
    }
    fim = novoNo;
        qtd++;
    }
    */
    public Object consultarPorPosicao(int pos){
        if(posicaoValida(pos)){
         No aux = ini;
            for (int i = 0; i <pos; i++) {
            aux = aux.getProx();
            
        }
        return aux.getValor();
        }else{
            System.out.println("Posição inválida!");
            return null;
        } 
    }
     public Object consultarPorObject(Object valor){
           int cont = 0;
         No aux = ini;
         while(aux !=null){
             if(aux.getValor()==valor){
                 return  cont;
             
         }
         cont ++;
         aux = aux.getProx();
           
    }
     return -1;
}
    
    //Para Imprimir onderInversa
    void push(Object valor) {
           
            No no5 = new No(valor);
		if (topo == null) {
			
			topo = no5;
		}else {
                    no5.setProx(topo);
                    topo = no5;
                   
		}
	}
    public void consultarOrdemInversa(){
       No no7 = new No();
       no7 = topo;
       while(no7!=null){
           System.out.println(no7.getValor());
           no7 = no7.getProx();
       }
	}
	
    
       
    public  boolean posicaoValida(int pos){
        return pos >= 0 && pos <qtd;
    }
    // atualizar meu inicio para o proximo nó  mas antes de atualizar o inicio eu guardo o inicio
    //antes dele ser desenfileirado
     public Object desenfileirar(){
        if(!isEmpty()){
            Object temp = ini.getValor();
            ini = ini.getProx();
            qtd--;
          return temp;
        }
        else{
            System.out.println("Fila vazia"); 
            return null; 
        }
       
          
    }
     public Object primeiroDaFila(){
         if(!isEmpty()){
             return ini.getValor();
         }
         else{
             System.out.println("Fila vazia");
             return null;
         }
     }
     public void imprimir() {
          No aux = ini;
                while(aux != null){
                    System.out.println(aux.getValor()+ " ");
                    aux = aux.getProx();
                    
                }
		       System.out.println();
	}
    public boolean isEmpty(){
        return qtd==0;
    }
    
}
