/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaFila;

/**
 *
 * @author Vitória
 */
public class No {
    private Object valor;
    private No prox;
    
    public No(Object valor){
        this.valor=valor;
    }
    public No(){
        
    }
    
    public void setValor(Object valor){
        this.valor = valor;
    }
    public Object getValor(){
        return valor;
    }
    public void setProx(No prox){
        this.prox = prox;
    }
    public No getProx(){
        return prox;
    }
    
}
