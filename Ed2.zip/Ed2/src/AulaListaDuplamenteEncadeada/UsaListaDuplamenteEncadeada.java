/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AulaListaDuplamenteEncadeada;

/**
 *
 * @author Vitória
 */
public class UsaListaDuplamenteEncadeada {
    public static void main(String[] args) {
		ListaDuplamenteEncadeada lista = new ListaDuplamenteEncadeada();
		lista.insertLast("G");
		lista.insertFirst("A");
		lista.insertFirst("B");
		lista.insertLast("X");
		lista.insertLast("H");
		lista.insertFirst("C");
		lista.imprimir();
	}
}


