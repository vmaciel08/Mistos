/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AulaListaDuplamenteEncadeada;

/**
 *
 * @author Vitória
 */

public class UsaSequenciaDuplamenteEncadeada extends SequenciaDuplamenteEncadeada {
    
    public static void main(String[] args) {
        SequenciaDuplamenteEncadeada sde = new SequenciaDuplamenteEncadeada();
        sde.insertFirst("A");
        sde.insertFirst("B");
        sde.insertFirst("C");
        sde.insertFirst("D");
       sde.imprimir();
    }
}
