/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AulaListaDuplamenteEncadeada;

import javax.swing.JOptionPane;

/**
 *
 * @author Vitória
 */
public class SequenciaDuplamenteEncadeada extends ListaDuplamenteEncadeada {
    
    
    //Criar um método para retornar o nó que encontra-se em uma 
	//determinada posição passada por parâmetro
	public DNode acharElementoNaPosicao(int pos) {
		if(validarPosicao(pos)) {
			if (pos < size()/2) {
				DNode aux = retornaPrimeiroNo();
				for (int i = 0; i < pos; i++) {
					aux = aux.getProx();
				}
				return aux;
			}else {
				DNode aux = retornaUltimoNo();
				for (int i = size()-1; i > pos; i--) {
					aux = aux.getAnt();
				}
				return aux;
			}
		}else {
			System.out.println("Posição inválida");
			return new DNode(null, null, "");
		}
	}
	//Criar um método para retornar a primeira ocorrência (posição) de um objeto
	//passado por parâmetro
	public int acharPosicaoDoElemento(Object valor) {
		DNode aux = retornaPrimeiroNo();
		for (int pos = 0; pos < size(); pos++) {
			if (aux.getValor() == valor) {
				return pos;
			}
			aux = aux.getProx();
		}
		return -1;
	}
	
	public boolean validarPosicao(int pos) {
		return pos >= 0 && pos < size();
	}
	


    public void inserirOrdenado(int valor){
        boolean achei = false;
        if(isEmpty()){
            insertFirst(valor);
        }
        DNode aux = retornaPrimeiroNo();
       while(aux != retornaUltimoNo().getProx() && !achei){
           if(valor <= (int)aux.getValor()){
           DNode novoNo = new DNode(aux.getAnt(), aux, valor);
           aux.getAnt().setProx(novoNo);
           aux.setAnt(novoNo);
           tam ++;
           achei = true;
       }
           aux = aux.getProx();
       }
        
    }
    public Object removerNaPosicao(int pos){
        if(validarPosicao(pos)){
            DNode aux = retornaPrimeiroNo();
            for (int i = 0; i < pos; i++) {
                aux = aux.getProx();
                
            }
            Object temp = aux.getValor();
            //alterar o proximo do anterior do aux
            aux.getAnt().setProx(aux.getProx());
            //alterar o anterior do proximo do aux
            aux.getProx().setAnt(aux.getAnt());
            tam --;
            return temp;
        }
        return null;
    }
    public Object removerDaUltimaPosicao(){
        return removerNaPosicao(size()-1);
    }
     public Object removerDaPrimeiraPosicao(){
         return removerNaPosicao(0);
     }
}



