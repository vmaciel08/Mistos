/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AulaListaDuplamenteEncadeada;

/**
 *
 * @author Vitória
 */
public class ListaDuplamenteEncadeada {
    private DNode ini;
    private DNode fim;
    protected int tam;
    
    
    
    public ListaDuplamenteEncadeada(){
        tam = 0;
        ini = new DNode(null, null, null);
        fim = new DNode(ini,null,null);
        ini.setProx(fim);
        
    }
    public void insertFirst(Object valor){
        DNode novoNo = new DNode(ini, ini.getProx(),valor);
        ini.getProx().setAnt(novoNo);
        ini.setProx(novoNo);
        tam++;
    }
    public void insertLast(Object valor){
        DNode novoNo = new DNode(fim.getAnt(),fim,valor);
        //procurei quem tava anterior ao fim e setei um novo valor a esse fim
        fim.getAnt().setProx(novoNo);
        //atualizei o fim
        fim.setAnt(novoNo);
    }
    public Object removeFirst(){
        Object temp = ini.getProx().getValor();
        ini.setProx(ini.getProx().getProx());
        ini.getProx().setAnt(ini);
        tam--;
        return temp;
    }
    public Object removeLast(){
        Object temp2 = fim.getAnt().getValor();
        fim.setAnt(fim.getAnt().getAnt());
        fim.getAnt().setProx(fim);
        tam --;
        return temp2;
    }
   public void inserirDepoisDoNo(DNode no, Object valor) {
		DNode novoNo = new DNode(no, no.getProx(), valor);
		no.getProx().setAnt(novoNo);
		no.setProx(novoNo);
		tam++;
	}
	
	public void inserirAntesDoNo(DNode no, Object valor) {
		DNode novoNo = new DNode(no.getAnt(), no, valor);
		no.getAnt().setProx(novoNo);
		no.setAnt(novoNo);
		tam++;
	}
        public DNode retornaPrimeiroNo() {
		if (!isEmpty()) {
			return ini.getProx();
		}else {
			System.out.println("Lista vazia");
			return null;
		}
		
	}
	
	public DNode retornaUltimoNo() {
		if (!isEmpty()) {
			return fim.getAnt();
		}else {
			System.out.println("Lista vazia");
			return null;
		}
	}
        public void imprimir() {
		DNode aux = ini.getProx();
		while(aux != fim) {
			System.out.print(aux.getValor());
			aux = aux.getProx();
		}
		System.out.println();
	}
        public int size(){
            return tam;
        }
	
	public boolean isEmpty() {
		return tam == 0;
	}
}
	
	
        


   

