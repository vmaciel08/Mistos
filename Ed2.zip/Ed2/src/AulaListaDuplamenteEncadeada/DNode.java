/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AulaListaDuplamenteEncadeada;



/**
 *
 * @author Vitória
 */
public class DNode {
    private Object valor;
    private DNode ant;
    private DNode prox;
    
    public DNode(DNode prox, DNode ant, Object valor){
        this.ant = ant;
        this.prox = prox;
        this.valor = valor;
    } 
    public void setValor(Object valor){
        this.valor = valor;
    }
    public Object getValor(){
        return valor;
    }
    public void setProx(DNode prox){
        this.prox = prox;
    }
    public DNode getProx (){
        return prox;
    }
    public void setAnt(DNode ant){
        this.ant= ant;
    }
    public DNode getAnt(){
        return ant;
    }
    
}
