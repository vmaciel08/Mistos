/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vitória
 */
public class PilhaEncadeada {
        private No topo;
	private int qtd;
	
	public void push(Object elemento) {
		No novoNo = new No(elemento, topo);
		topo = novoNo;
		qtd++;
	}
	
	public Object pop() {
		if (!isEmpty()) {
			Object temp = topo.getValor();
			topo = topo.getAnt();
			qtd--;
			return temp;
		}else {
			System.out.println("Pilha vazia");
			return null;
		}
	}
	
	public Object top() {
		if (!isEmpty()) {
			return topo.getValor();
		}else {
			System.out.println("Pilha vazia");
			return null;
		}
	}
	
	public int size() {
		return qtd;
	}
	
	public boolean isEmpty() {
		return qtd == 0;
	}
	
	public void push1(Object elemento) {
		No novoNo = new No();
		novoNo.setValor(elemento);
		novoNo.setAnt(topo);
		topo = novoNo;
		qtd++;
	}
	public void push2(Object elemento) {
		No novoNo = new No(elemento);
		novoNo.setAnt(topo);
		topo = novoNo;
		qtd++;
	}
	
	public void imprimir() {
		No aux = topo;
		while(aux != null) {
			System.out.print(aux.getValor() + " ");
			aux = aux.getAnt();
		}
	}
}
