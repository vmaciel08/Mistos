/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaSimplesmenteEncadeada;

import javax.swing.JOptionPane;

/**
 *
 * @author Vitória
 */
public class ListaSimplesmenteEncadeada {
     DNode ini,fim;
    int tam;

    public ListaSimplesmenteEncadeada(){
        ini = fim = null;
        tam = 0;
    }

    public int getTotalNos(){
        return tam;
    }

    public boolean checkIfListaVazia(){
        if (getTotalNos() == 0){
            return true;
       }
       return false;
    }

    public void inserirNoInicio(DNode n) {
        if ( tam == 0 ){
            ini = ini = n;
        }
        else{
            n.prox = ini;
            ini = n;
        }
        tam++;
    }

    public void inserirNoFim(DNode n){
        // caso não existam nós inseridos,
        // insere o primeiro nó (n) na lista
        if ( checkIfListaVazia() ){
            ini = fim = n;
        }
        else{
            fim.prox = n;
            fim = n;
       }
       tam++;
    }

    public void excluirNo(DNode n){
        DNode noAtual;
        DNode noAnterior;
        noAtual = noAnterior = ini;
        int contador = 1;

        if (checkIfListaVazia() == false){
            while (contador <= getTotalNos() &&
                     noAtual.valor != n.valor){
                noAnterior = noAtual;
                noAtual = noAtual.prox;
                contador++;
            } 

        if(noAtual.valor == n.valor){
            if ( getTotalNos() == 1){
                ini = fim = null;
           }
           else{
               if (noAtual == ini){
                  ini= noAtual.prox;
               }
               else{
                   noAnterior.prox = noAtual.prox;
               }
           }
           tam--;
        }
    }
}

public void exibir(){
    DNode temp = ini;
    String valores = "";
    int contador = 1;
    if ( checkIfListaVazia() == false ){
        while (contador <= getTotalNos()){
            valores += Integer.toString(temp.valor)+"-";
            temp = temp.prox;
            contador++;
        }
    }
    JOptionPane.showMessageDialog(null, valores);
 }
}