/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaSimplesmenteEncadeada;

/**
 *
 * @author Vitória
 */
public class UsaListaSimplesmenteEncadeada {
 public static void main(String[] args) {
 ListaSimplesmenteEncadeada l1 = new ListaSimplesmenteEncadeada();

 l1.inserirNoFim(new DNode(2));
 l1.inserirNoFim(new DNode(12));
 l1.inserirNoInicio(new DNode(22));
 l1.inserirNoFim(new DNode(32));
 l1.inserirNoFim(new DNode(2));

 l1.exibir();

 l1.excluirNo(new DNode(12));
 l1.exibir();
 }
}

