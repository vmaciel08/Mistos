/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Polimorfismo;

/**
 *
 * @author Vitória
 */
public class Quadrado extends FormaGeometrica {

    
   /* public double CalcArea() {
        double resultado;
        resultado = Math.pow(getLado1(),2);
        return resultado;
        //To change body of generated methods, choose Tools | Templates.
    }*/
    //Para esse construtor funcionar e o super foi necessário criar um construtor para FormaGeometrica
    //pois o super vai chamar as variaveis do construtor da super classe
public Quadrado(double lado1){
    super(lado1);
}
public double CalcArea(){
    return Math.pow(getLado1(),2);
}
public double CalcPerimetro(){
    return 4*getLado1();
}
  public void exibirDados(){
        System.out.println("***");
        System.out.println("Area:"+CalcArea());
        System.out.println("Perimetro:"+CalcPerimetro());
        System.out.println("Lado: "+getLado1());
        System.out.println(" *** ");
    }  

    
   
}
