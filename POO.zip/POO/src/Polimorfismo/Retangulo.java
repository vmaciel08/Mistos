/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Polimorfismo;

/**
 *
 * @author Vitória
 */
public class Retangulo extends FormaGeometrica{
    
    private double lado2;
    public void setLado2(double lado2){
        this.lado2 = lado2;
    }
    public double getLado2(){
        return lado2;
    }
    public Retangulo(double lado1, double lado2)
    {
        
        super(lado1);
        this.lado2 = lado2;
    }
    public double CalcArea(){
        return (getLado1()*getLado2())*2;
    }
    public double CalcPerimetro(){
        return (getLado1() * 2)+ (getLado2() * 2) ;
    }
    
}
