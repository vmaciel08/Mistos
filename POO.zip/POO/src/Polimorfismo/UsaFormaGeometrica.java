/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Polimorfismo;

/**
 *
 * @author Vitória
 */
public class UsaFormaGeometrica {
    public static void main (String[]args){
        
        Quadrado qd = new Quadrado(2.0);
        TriangoEquilatero te = new TriangoEquilatero(3.0);
        Retangulo rt = new Retangulo(4.0,2.0);
        System.out.println("Quadrado");
                qd.exibirDados();
       
        System.out.println("equilatero");
       // te.CalcArea();
        //te.CalcPerimetro();
        te.exibirDados();
        
        System.out.println("Retangulo");
        //rt.CalcArea();
        //rt.CalcPerimetro();
        rt.exibirDados();
        
    }
    
}
