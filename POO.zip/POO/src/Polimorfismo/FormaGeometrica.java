/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Polimorfismo;

/**
 *
 * @author Vitória
 */
//deixei abstract
public   class FormaGeometrica {
    
    private double lado1;
    
    public double getLado1(){
        return lado1;
    }
    public void setLado1(double lado1){
        this.lado1 = lado1;
    }
    public  void exibirDados(){
        System.out.println("***");
        System.out.println("Area:"+CalcArea());
        System.out.println("Perimetro:"+CalcPerimetro());
        System.out.println("Lado: "+getLado1());
        System.out.println(" *** ");
   }
    public  double CalcArea(){
        return 0;
    }
    
    public  double CalcPerimetro(){
        return 0;
   }
      public FormaGeometrica(double lado1){
          this.lado1 = lado1;
          
      }  
}
