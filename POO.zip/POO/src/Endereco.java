/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vitória
 */
public class Endereco {
    private String cidade; //Endereço
    private String rua; // Endereço
    private String bairro; // Endereço
    private int numero;
     public void setCidade (String cidade){
         this.cidade = cidade;
     }
     public String getCidade (){
         return cidade;
     }
       public void setRua (String rua){
         this.rua = rua;
     }
     public String getRua (){
         return rua;
     }
       public void setBairro (String bairro){
         this.bairro = bairro;
     }
     public String getBairro (){
         return bairro;
     }
     public void setNumero(int numero){
         this.numero = numero;
     }
     public int getNumero(){
         return numero;
     }
}
