/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Abstrata;

/**
 *
 * @author Vitória
 */
public abstract class Animal {
    
    public Animal( String nome, int idade){
		this.nome = nome;
		this.idade = idade;
	}
	
	private String nome;
	private int idade;
	
	public String getNome(){
		return nome;
	}
	public void setNome(String nome){
		this.nome = nome;
	}
	public int getIdade(){
		return idade;
	}
	public void setIdade(int idade){
		this.idade = idade;
	}
	public void exibirDados(){
		System.out.println("Nome: "+getNome());
		System.out.println("Idade: "+ getIdade());
	}
        //metodo abstract (obrigatório ser usado pelas classes que herdam desta)
	public abstract void emitirSom();
}

    

