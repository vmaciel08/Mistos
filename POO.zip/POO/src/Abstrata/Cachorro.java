/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Abstrata;

/**
 *
 * @author Vitória
 */
public class Cachorro extends Animal {
    //criado um construtor cachorro que recebe como parâmetro os mesmo atributos da classe animal
    //todavia para ser possível acessa-los e utilizados é necessário utilizar o método SUPER
    public Cachorro(String nome, int idade){
		super(nome, idade);
		
	}
    private String seila;
    public void setSeila(String seila){
        this.seila = seila;
    }
    public String getSeila(){
        return seila;
    }
    //Como é obrigatório usar o método abstract, ele foi chamado e seu corpo enfim foi alterado
	public void emitirSom(){
		System.out.println("Som: AuAuAuAu");
	}
	
}

    

