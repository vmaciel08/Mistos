/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Abstrata;

/**
 *
 * @author Vitória
 */
public class UsaAnimal {
    public static void main(String[] args) {
        //percebe-se que as alterações são feitas na propria criação dos objetos
		Cachorro c1 = new Cachorro("Marley", 3);
		Gato g1 = new Gato("Clementina", 1);
		System.out.println("Gato ----------");
		g1.exibirDados();
		g1.emitirSom();
		System.out.println("Cachorro ----------");
		c1.exibirDados();
		c1.emitirSom();
                c1.exibirDados();
		
	}

}

    

