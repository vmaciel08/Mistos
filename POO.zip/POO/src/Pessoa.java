/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vitória
 */
public abstract class Pessoa {
    private String nome; // dados pessoais
    private int idade; // dados pessoais
    private int telefone; // dados pessoais
   
    public Pessoa (String nome, int idade){
       this.nome = nome;
        this.idade = idade;
    }
    private Endereco ed;
    private Trabalho tb;
    
    public void setEndereco(Endereco ed){
        this.ed = ed;
    }
    public Endereco getEndereco(){
        return ed;
    }
    
    public void setTrabalho(Trabalho tb){
        this.tb = tb;
    }
    public Trabalho getTrabaho(){
        return tb;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
     public String getNome (){
         return nome;
     }
     public void setIdade(int idade){
         this.idade = idade;
     }
     public int getIdade(){
         return idade;
     }
     public void setTelefone(int telefone){
         this.telefone= telefone;
     }
     public int getTelefone(){
         return telefone;
     }
     
     public abstract void exibirDados();
     
     
}
