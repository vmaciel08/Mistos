/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vitória
 */
public class PessoaFisica extends Pessoa {
    private String cpf;
    
    public PessoaFisica (String cpf, String nome, int idade){
        super(nome, idade);
        this.cpf =cpf;
    }
    
    public void setCPF(String cpf){
        this.cpf = cpf;
    }
    public String getCPF(){
        return cpf;
    }
    
    public void exibirDados(){
        System.out.println("cpf: "+ getCPF());
        System.out.println("nome:"+ getNome());
        System.out.println("idade: "+getIdade());
    }
    
}
