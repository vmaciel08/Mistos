/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

/**
 *
 * @author Vitória
 */
public class Cachorro extends Animal implements Mamifero {

    public Cachorro(String nome){
        super(nome);
    }
    @Override
    public void emitirSom() {
        System.out.println("AuAuAuAu");
    }

    @Override
    public void exibirDados() {
        System.out.println("Nome: Cachorro");
        System.out.println("Som: ");
        emitirSom();
    }
       public void mamar(){
           mamar();
        
    
    }
    
    
    
}
