/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Heranca;

/**
 *
 * @author Vitória
 */
public class UsaFuncionario {
    public static void main(String[] args) {
        
        Salario sl1 = new Salario();
        sl1.setValor(1200.00);
        
        Gerente gr1 = new Gerente();
        gr1.setDepartamento("BLoco a");
        gr1.setCPF("34982489823");
        gr1.setId(2);
        gr1.setNome("Carlin Mastruz");
        gr1.setRg("9283284428");
        gr1.imprimir();
        System.out.println("");
        
        Funcionario f = new Funcionario();
           f.setId(1);
           f.setNome("José Maria");
           f.setRg("8372847421");
           f.setCPF("2983231983");
           f.setSalario(sl1);
           f.imprimir();
    
        
    }
    
}
