/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Heranca;

/**
 *
 * @author Vitória
 */
public class UsaVeiculo {
    
    public static void main(String[] args) {
        
        //Criei um Objeto tipo carro para ter acesso as váriaveis dele
        Carro cr1 = new Carro("Carro", "bmw1234", "BMW", "320i");
        
        //Preenchi os dados dos atributos
        System.out.println("Tipo: "+cr1.getTipo());
        System.out.println("Placa: " + cr1.getPlaca());
        System.out.println("Marca: "+ cr1.getMarca());
        System.out.println("Modelo: "+ cr1.getModelo());
        
        
        
    }
    
    
}
