/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Heranca;

/**
 *
 * @author Vitória
 */
public class Veiculo {
    //Criando atributos
    private String tipo;
    private String placa;
    
    //criando métodos de acessa-los
    public void setTipo(String tipo){
        this.tipo = tipo;
    }
    public String getTipo(){
        return tipo;
    }
    public void setPlaca(String placa){
        this.placa = placa;
    }
    public String getPlaca(){
        return placa;
    }
    //criando um construtor para veiculo para inicializar as variáveis
    public Veiculo(String tipo, String placa){
        this.placa= placa;
        this.tipo = placa;
    } 
    
}
