/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Heranca;

/**
 *
 * @author Vitória
 */
public class Carro extends Veiculo{
    //criando atributos
    private String marca;
    private String modelo;
    
    //Criando métodos de acessar os atributos
    public void setMarca(String marca){
        this.marca=marca;
    }
    
    public String getMarca(){
        return marca;
    }
    public void setModelo(String modelo){
        this.modelo= modelo;
    }
    public String getModelo(){
        return modelo;
    }
    //Criando um construtor Carro que vai receber como parametro os atributos de Veiculo e de Carro
    public Carro(String tipo, String placa,String marca, String modelo){
        //Mas para não da erro é necessário criar o super que é um método de acessar os atributos da superClasse Veiculo
       super(tipo,placa);
       //Essa parte da estrutura desse método é similar a estrutura de um método set pois aqui ja poderia ser possível
       //inserir valores aos atributos
        this.marca = marca;
        this.modelo = modelo;
        
    }
    
    
    
}
