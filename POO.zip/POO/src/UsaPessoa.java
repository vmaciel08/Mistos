/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vitória
 */
public class UsaPessoa {
    public static  void main(String[] args){
        
       Trabalho tb1 = new Trabalho();
       tb1.setProfissao("Estagiário");
       tb1.setSalario(600.00);
       tb1.setTempoServico("Um ano");
       
       Endereco ed1 = new Endereco();
       ed1.setRua("Rua dos bobos");
       ed1.setNumero(0);
       ed1.setBairro("Maravilha");
       PessoaFisica pf1 = new PessoaFisica("43244","jose", 12);
      // pf1.setCPF("kjdns");
       pf1.exibirDados();
      // Pessoa ps1 = new Pessoa();
      // ps1.setNome("João Ninguém");
      // ps1.setIdade(18);
      // ps1.setTelefone(3232434);
      // ps1.setTrabalho(tb1);
      // ps1.setEndereco(ed1);
       
        //System.out.println(ps1.getNome());
        //System.out.println(ps1.getTrabaho().getProfissao());
        //System.out.println();
         
        
       //Pessoa ps2 = new Pessoa();
      // ps2.setNome("Maria Sefoi");
      // ps2.setIdade(48);
      // ps2.setTelefone(8743432);
       //ps2.setTrabalho(tb1);
      // ps2.setEndereco(ed1);
      //System.out.println(ps2.getNome());
      //System.out.println(ps2.getTrabaho().getProfissao());
    
       
    }
}
