/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vitória
 */
public class Trabalho {
    private String profissao; //trabalho 
    private double salario; // trabalho
    private String  tempoServico; // trabalho
    
     public void setProfissao(String profissao){
          this.profissao = profissao;
      }
     public String  getProfissao(){
         return profissao;
     }
     public void setSalario(double salario){
         this.salario = salario;
     }
     public double getSalario(){
         return salario;
     }
     public void setTempoServico(String tempoServico){
         this.tempoServico = tempoServico;
     }
     public String getTempoServico(){
         return tempoServico;
     }
}
